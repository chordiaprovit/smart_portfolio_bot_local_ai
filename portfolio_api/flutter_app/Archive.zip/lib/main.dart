import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'services/http_portfolio_service.dart';
import 'services/mock_portfolio_service.dart';
import 'state/app_state.dart';
import 'screens/splash_screen.dart';

void main() {
  const baseUrl = String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:8000');
  const useMock = bool.fromEnvironment('USE_MOCK', defaultValue: false);

  final service = useMock ? MockPortfolioService() : HttpPortfolioService(baseUrl);
  Image.asset('/Users/provitchordia/PycharmProjects/smart_portfolio_bot_local_ai/portfolio_api/flutter_app/assets/app_icon.png', width: 120, height: 120);
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState(service),
      child: const App(),
    ), 
  );
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Portfolio Health',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const SplashScreen(),
    );
  }
}
